<?php

include 'config.php';

// $username =$_GET('username');
// $userpassword =$_GET('userpassword');
// $usertype =$_GET('usertype');
// $lat =$_GET('lat');
// $lon =$_GET('lon');

// if(isset($_GET['submit'])){
    $username =$_GET['username'];
    $userpassword =$_GET['userpassword'];
    $usertype =$_GET['usertype'];
    $lat =$_GET['lat'];
    $lon =$_GET['lon'];
   
   echo $username;

    if(empty($username)|| empty($userpassword)|| empty($lat) || empty($lon)){
    echo "<h1>please fill all fields</h1>";
    }
    else{
 
       $result = mysqli_query($con,"INSERT INTO `user` (`username`, `userpassword`, `usertype`, `userstatus`,`lat`, `lon`) 
       VALUES ('$username','$userpassword', '$usertype',0, $lat, $lon)");
       if($result){
           echo "<h1>Registered</h1>";
       }
       else{
        echo "<h1>Not Registered</h1>";
       }
    }

    header("location:Products.php");
    // }
?>
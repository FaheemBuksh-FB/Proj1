<?php
 $con = mysqli_connect("localhost","root","","smartsolutions");
?>